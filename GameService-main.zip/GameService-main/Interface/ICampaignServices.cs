﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
    interface ICampaignServices
    {
        void MakeCampaign();
    }
}
