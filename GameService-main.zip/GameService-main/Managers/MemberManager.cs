﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
    class MemberManager
    {
        public void Add(Customer customer)
        {
            Console.WriteLine("Customer added.");
        }

        public void Update(Customer customer)
        {
            Console.WriteLine("Customer added.");
        }

        public void Delete(Customer customer)
        {
            Console.WriteLine("Customer added.");
        }
    }
}
