﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
     public class Customer
    {
        public string TcNo { get; set; }
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        public string DogumTarihi { get; set; }

    }
}
