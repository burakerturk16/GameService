﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
    class Member:Customer
    {
        public int Id { get; set; }
        public string MusteriNo { get; set; }
        public string Sehir { get; set; }
    }
    
}
