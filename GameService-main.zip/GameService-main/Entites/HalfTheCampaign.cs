﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
    class HalfTheCampaign : ICampaignServices
    {
        public void MakeCampaign()
        {
            Console.WriteLine("HalfTheCampaign was done.");
        }
    }
}
