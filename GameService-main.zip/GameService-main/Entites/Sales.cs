﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
    class Sales
    {
        public int SalesId { get; set; }
        public DateTime Sellby { get; set; }
        public int  SalePrice { get; set; }

    }
}
