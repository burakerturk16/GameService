﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
    class E_DevletVerification : IVerificationService
    {
        public void CheckInformation()
        {
            Console.WriteLine("E-devlet verification successful.");
        }
    }
}
