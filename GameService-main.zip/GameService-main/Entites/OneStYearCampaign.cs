﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameService
{
    class OneStYearCampaign : ICampaignServices
    {
        public void MakeCampaign()
        {
            Console.WriteLine("OneStYearCampaign  was done.");
        }
    }
}
